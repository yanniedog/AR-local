param([Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{40}$')][string]$ReceiverCommit)
$ErrorActionPreference='Stop'
$runtime='2607ed681d5d3c1da66f9c3c0109cff524e02338'
$previousRoot='C:\code\backups\AR-local-user-session\source-resilience-20260907-v7'
$newRoot='C:\code\backups\AR-local-user-session\source-lan-fallback-20260908'
$oldDigest='b38601a31751f052c11b8d96c23d90acdc138afdddbef4c710ae87b580745e8e'
$priorReceipt='701266621fb077221b7acc0f9582710296d939ee98f911b87c7b6b2169c53f46'
$evidence='C:\code\backups\AR-local-user-session\lan-recovery-20260908\installation'
if(Test-Path -LiteralPath $newRoot){throw 'New receiver root already exists; preserve and reassess.'}
if((Get-ScheduledTask -TaskName 'AR-local user-session backup').State.ToString() -cne 'Ready'){throw 'Task is active.'}
$oldConfig=Join-Path $previousRoot 'user-session-backup.json'
if((Get-FileHash -LiteralPath $oldConfig).Hash.ToLowerInvariant() -cne $oldDigest){throw 'Previous config changed.'}
$config=Get-Content -LiteralPath $oldConfig -Raw | ConvertFrom-Json
$pointer=Get-Content -LiteralPath (Join-Path $config.target 'catalog\latest-scheduled.json') -Raw | ConvertFrom-Json
if($pointer.record_sha256 -cne $priorReceipt){throw 'Latest backup changed; reassess predecessor.'}
$recordPath=Join-Path $config.target $pointer.record_path
if((Get-FileHash -LiteralPath $recordPath).Hash.ToLowerInvariant() -cne $priorReceipt){throw 'Prior receipt bytes changed.'}
$record=Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
if($record.result -cne 'PASS' -or $record.protected_code_sha -cne $runtime -or $record.candidate_code_sha -cne $config.candidate_sha){throw 'Prior identity changed.'}
$live=& ssh -o BatchMode=yes -o ConnectTimeout=15 ar-local-pi5-lan 'git -C /srv/ar-local/AR-local rev-parse HEAD; git -C /srv/ar-local/AR-local status --porcelain'
if($LASTEXITCODE -ne 0 -or ($live -join "`n").Trim() -cne $runtime){throw 'Production is not clean at the verified runtime.'}
& git -C C:\code\AR-local fetch origin main
if($LASTEXITCODE -ne 0){throw 'Fetch failed.'}
& git -C C:\code\AR-local merge-base --is-ancestor $ReceiverCommit origin/main
if($LASTEXITCODE -ne 0){throw 'Receiver commit is not merged into main.'}
$source=Join-Path $newRoot 'source'
& git -C C:\code\AR-local worktree add --detach $source $ReceiverCommit
if($LASTEXITCODE -ne 0){throw 'New immutable checkout failed.'}
$config.receiver=$source
$config.candidate_sha=$ReceiverCommit
$config | Add-Member -Force -NotePropertyName previous_runtime -NotePropertyValue ([ordered]@{
  production_sha=$runtime;receiver_sha=$record.candidate_code_sha;record_sha256=$priorReceipt
})
$config | Add-Member -NotePropertyName lan_fallback_ipv4 -NotePropertyValue '192.168.20.19'
$configPath=Join-Path $newRoot 'user-session-backup.json'
$payload=[Text.UTF8Encoding]::new($false).GetBytes(($config | ConvertTo-Json -Depth 10))
$stream=[IO.File]::Open($configPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$stream.Write($payload,0,$payload.Length)}finally{$stream.Dispose()}
$digest=(Get-FileHash -LiteralPath $configPath).Hash.ToLowerInvariant()
& (Join-Path $source 'update_laptop_backup_user_session.ps1') -OldConfigPath $oldConfig -OldConfigSha256 $oldDigest -ConfigPath $configPath -ConfigSha256 $digest -EvidenceDirectory $evidence
[ordered]@{receiver_commit=$ReceiverCommit;config_path=$configPath;config_sha256=$digest;backup_started=$false} | ConvertTo-Json
