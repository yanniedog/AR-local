"""Independently restore the operator-recovery backup, without claiming a natural trigger."""
import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--release', type=Path, required=True)
p.add_argument('--config-sha256', required=True)
p.add_argument('--scheduled-sha256', required=True)
p.add_argument('--observation-date', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
sys.path.insert(0, str(a.release / 'source'))
import laptop_backup_user_session as user
import laptop_pull_backup as receiver
from laptop_backup_atomic import ReceiverLock
from laptop_backup_runtime_lineage import authenticated_runtime_pairs
from laptop_backup_transition_contract import partial_paths

config = user.load_config(a.release / user.CONFIG_NAME, a.config_sha256)
user.verify_release(config)
target = Path(config['target'])
if a.output.exists():
    raise ValueError('Refusing to overwrite an existing verification report')
with ReceiverLock(target / 'user-session-lock'), ReceiverLock(target):
    entries = receiver.catalog_entries(target / 'catalog/generations.jsonl')
    pointer = json.loads((target / 'catalog/latest-scheduled.json').read_bytes())
    record_path = target / pointer['record_path']
    assert user.digest(record_path) == pointer['record_sha256'] == a.scheduled_sha256
    record = json.loads(record_path.read_bytes())
    assert record['result'] == 'PASS'
    status = record['detail'].get('after', record['detail'])
    assert status['status'] == 'UP_TO_DATE'
    assert record['candidate_code_sha'] == config['candidate_sha']
    assert record['protected_code_sha'] == config['protected_sha']
    assert status['observation']['observation_date'] == a.observation_date
    pairs = authenticated_runtime_pairs(target, config['previous_runtime'], {
        'operator': config['operator_sid'], 'plan_git_commit': '9094a8e115958fcaf2cb36525736bd5e297e6b04'})
    by_sequence = {entry['sequence']: entry for entry in entries}
    for entry in entries:
        assert user.digest(target / entry['receipt_path']) == entry['receipt_sha256']
    results = []
    for kind in ('observation', 'control', 'macro'):
        current = status[kind]
        assert current['status'] == 'UP_TO_DATE'
        entry = by_sequence[current['catalog_sequence']]
        path = user.unlinked(Path(current['receipt_path']))
        assert path == target / entry['receipt_path']
        receipt = json.loads(path.read_bytes())
        manifest_path = path.parent / 'source-manifest.json'
        assert user.digest(manifest_path) == receipt['source_manifest_sha256'] == entry['source_manifest_sha256']
        manifest = json.loads(manifest_path.read_bytes())
        archive = path.parent / (receipt['kind'] + '.tar.zst')
        assert archive.stat().st_size == receipt['archive_bytes']
        assert user.digest(archive) == receipt['archive_sha256'] == entry['archive_sha256']
        checks = receiver.restore_verify_archive(target, archive, manifest, receipt['kind'])
        results.append({'sequence': entry['sequence'], 'kind': receipt['kind'], 'receipt_path': str(path),
                        'receipt_sha256': entry['receipt_sha256'], 'archive_sha256': entry['archive_sha256'],
                        'archive_bytes': receipt['archive_bytes'], 'checks': checks})
        print(json.dumps({'sequence': entry['sequence'], 'result': 'PASS',
                          'restored_files': checks['files_verified']}), flush=True)
    assert not partial_paths(target), 'active partials remain; preserve and reassess'
    report = {'at_utc': datetime.now(timezone.utc).isoformat(), 'result': 'PASS',
              'trigger': 'operator-recovery', 'natural_0600_result': 'FAIL',
              'earlier_operator_failure_sha256': '85bae5c09a572529c2083b125370ac29b69f00724cc3274f4e48368d15ae2e73',
              'candidate_sha': config['candidate_sha'], 'protected_sha': config['protected_sha'],
              'scheduled_path': str(record_path), 'scheduled_sha256': pointer['record_sha256'],
              'catalog_entries_verified': len(entries), 'historical_runtime_pairs': sorted(pairs),
              'generations': results, 'partials': [], 'uac_used': False,
              'exact_argv': sys.argv, 'verifier_sha256': user.digest(Path(__file__)),
              'proof_scope': 'Independent current archive restore and byte/metadata/database verification; natural trigger proof remains separate.'}
    with a.output.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2)
print(json.dumps({'result': 'PASS', 'report': str(a.output), 'sha256': user.digest(a.output)}), flush=True)
