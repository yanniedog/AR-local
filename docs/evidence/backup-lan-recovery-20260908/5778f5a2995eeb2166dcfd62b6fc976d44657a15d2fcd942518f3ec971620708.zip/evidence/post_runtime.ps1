$ErrorActionPreference='Stop'
$root='C:\code\backups\AR-local-user-session\lan-recovery-20260908'
$task=Get-ScheduledTask -TaskName 'AR-local user-session backup'
$info=Get-ScheduledTaskInfo -TaskName $task.TaskName
if($task.State.ToString() -cne 'Ready' -or $info.LastTaskResult -ne 0){throw 'Backup has not completed successfully.'}
$probe=@'
python3 - <<'PY'
import json,subprocess
root='/srv/ar-local/AR-local'
def run(*args):
 return subprocess.run(args,check=True,capture_output=True,text=True,timeout=30).stdout.strip()
state=dict(line.split('=',1) for line in run('systemctl','show','ar-local-daily.service','-p','ActiveState','-p','Result').splitlines())
publication=json.loads(run('python3','-B',root+'/scripts/pi_ingest_manifest_check.py','--json'))
print(json.dumps({'sha':run('git','-C',root,'rev-parse','HEAD'),'status':run('git','-C',root,'status','--porcelain'),
 'daily':state,'next_daily':run('systemctl','show','ar-local-daily.timer','-p','NextElapseUSecRealtime','--value'),
 'publication':publication}))
PY
'@
$raw=(($probe -replace "`r",'')+"`n"+'exit $?'+"`n") | & ssh -o BatchMode=yes -o ConnectTimeout=15 ar-local-pi5-lan bash -s
if($LASTEXITCODE -ne 0){throw 'Post-recovery Pi probe failed.'}
$pi=($raw -join "`n") | ConvertFrom-Json
if($pi.sha -cne '2607ed681d5d3c1da66f9c3c0109cff524e02338' -or $pi.status -or $pi.daily.ActiveState -cne 'inactive' -or $pi.daily.Result -cne 'success' -or -not $pi.publication.publication_current -or $pi.publication.manifest_run_date -cne '2026-09-08'){throw 'Post-recovery production state changed.'}
$smoke=& python C:\code\AR-local-backup-proof-0908\verify_local.py --base-url=http://100.78.28.10/ --require-banks-rates
if($LASTEXITCODE -ne 0){throw 'Post-recovery dashboard verification failed.'}
[xml]$oldLegacy=Get-Content -LiteralPath (Join-Path $root 'legacy-task-before.xml') -Raw
[xml]$newLegacy=Export-ScheduledTask -TaskName 'AR-local laptop backup'
foreach($section in @('Actions','Triggers','Principals','Settings')) {
  if($oldLegacy.Task.$section.OuterXml -cne $newLegacy.Task.$section.OuterXml){throw "Legacy task $section changed."}
}
$config='C:\code\backups\AR-local-user-session\source-lan-fallback-20260908\user-session-backup.json'
if((Get-FileHash -LiteralPath $config).Hash.ToLowerInvariant() -cne '4b7a812f01c4f3f027bcb5298f2a5aa5c53a7f9e345504fd78b80da53ea34bbf'){throw 'Receiver config changed.'}
$record=[ordered]@{result='PASS';at_hobart=(Get-Date -Format o);task_state=$task.State.ToString();task_result=$info.LastTaskResult;
  task_last_run=$info.LastRunTime.ToString('o');task_next_run=$info.NextRunTime.ToString('o');production_sha=$pi.sha;
  production_clean=$true;publication_current=$pi.publication.publication_current;run_date=$pi.publication.manifest_run_date;
  daily=$pi.daily;next_daily=$pi.next_daily;dashboard_smoke=($smoke -join "`n");legacy_task_unchanged=$true;
  free_bytes=(Get-PSDrive C).Free;floor_bytes=53687091200;uac_used=$false;trigger='operator-recovery';natural_0600_result='FAIL'}
if($record.free_bytes -lt $record.floor_bytes){throw 'Free-space floor breached.'}
foreach($name in @('post-runtime.json','task-terminal.xml')){if(Test-Path -LiteralPath (Join-Path $root $name)){throw 'Terminal evidence already exists.'}}
[IO.File]::WriteAllText((Join-Path $root 'task-terminal.xml'),(Export-ScheduledTask -TaskName $task.TaskName),[Text.Encoding]::Unicode)
[IO.File]::WriteAllText((Join-Path $root 'post-runtime.json'),($record|ConvertTo-Json -Depth 8))
$record|ConvertTo-Json -Depth 8
