"""Create an append-only proof packet after real operator recovery acceptance."""
import copy
import hashlib
import io
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

root = Path(r'C:\code\backups\AR-local-user-session\lan-recovery-20260908')
release = Path(r'C:\code\backups\AR-local-user-session\source-lan-fallback-20260908')
repo = Path(r'C:\code\AR-local-backup-proof-0908')
target = Path(r'C:\code\backups\AR-local-pi5-user')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
proof = load(root / 'independent-restore.json')
post = load(root / 'post-runtime.json')
config = load(release / 'user-session-backup.json')
assert proof['result'] == post['result'] == 'PASS'
assert post['task_result'] == 0 and post['task_state'] == 'Ready'
assert post['production_sha'] == config['protected_sha'] == proof['protected_sha']
assert post['production_clean'] and post['publication_current'] and post['run_date'] == '2026-09-08'
assert proof['candidate_sha'] == config['candidate_sha'] == 'cbf920eceedcfd5cc19bd75d86351ddbc7b39e2e'
assert digest(release / 'user-session-backup.json') == '4b7a812f01c4f3f027bcb5298f2a5aa5c53a7f9e345504fd78b80da53ea34bbf'
assert (target / 'catalog/generations.jsonl').read_bytes().startswith((root / 'catalog-prefix-before.jsonl').read_bytes())
pointer = load(target / 'catalog/latest-scheduled.json')
assert pointer['record_sha256'] == proof['scheduled_sha256']
record = load(target / pointer['record_path'])
assert record['result'] == 'PASS'
status = record['detail'].get('after', record['detail'])
assert status['status'] == 'UP_TO_DATE'

sources = {f'evidence/{p.relative_to(root).as_posix()}': p for p in root.rglob('*')
           if p.is_file() and p.suffix != '.pyc' and '__pycache__' not in p.parts}
sources['catalog/generations.jsonl'] = target / 'catalog/generations.jsonl'
sources['catalog/latest-scheduled.json'] = target / 'catalog/latest-scheduled.json'
for p in (target / 'catalog/scheduled-runs').glob('*.json'):
    sources[p.relative_to(target).as_posix()] = p
sources['catalog/failures/20260907T225338Z-643fd3f9200a4524889402753f16a780.json'] = target / 'catalog/failures/20260907T225338Z-643fd3f9200a4524889402753f16a780.json'
entries = [json.loads(line) for line in (target / 'catalog/generations.jsonl').read_bytes().splitlines()]
for entry in entries:
    p = target / entry['receipt_path']
    assert digest(p) == entry['receipt_sha256']
    sources[entry['receipt_path']] = p
for p in (release / 'logs').glob('*'):
    sources['receiver-logs/' + p.name] = p
for p in (target / 'user-session-executions').glob('*.json'):
    value = load(p)
    if value.get('candidate_sha') == config['candidate_sha']:
        sources['user-session-executions/' + p.name] = p
manifest = {'scope': 'Original operational evidence, complete catalog/receipt prefix and scheduled ancestry; bulk data archives remain at their recorded private paths.',
            'files': [{'entry': key, 'source_path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)}
                      for key, p in sorted(sources.items())]}
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
    for key, p in sorted(sources.items()):
        archive.writestr(key, p.read_bytes())
    archive.writestr('manifest.json', json.dumps(manifest, indent=2))
payload = buffer.getvalue()
archive_sha = hashlib.sha256(payload).hexdigest()
archive_dir = repo / 'docs/evidence/backup-lan-recovery-20260908'
archive_dir.mkdir(parents=True, exist_ok=True)
archive_path = archive_dir / (archive_sha + '.zip')
with archive_path.open('xb') as out:
    out.write(payload)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for item in manifest['files']:
        data = archive.read(item['entry'])
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']

now = datetime.now(timezone.utc)
ledger = repo / 'docs/PI_INGEST_PAYLOAD_RECOVERY_HANDOFF.md'
blocks = re.findall(r'```json\n(.*?)\n```', ledger.read_text(encoding='utf-8'), re.S)
prior = json.loads(blocks[-1])
assert prior['entry_id'] == 'HANDOFF-20260908-LAN-DISCOVERY-REPAIR'
entry = copy.deepcopy(prior)
entry.update(entry_id='HANDOFF-20260908-LAN-RECOVERY-VERIFIED', previous_entry_id=prior['entry_id'],
             created_at_utc=now.isoformat(), created_at_hobart=now.astimezone(ZoneInfo('Australia/Hobart')).isoformat(),
             result='PASS', current_phase='Ordinary-user LAN repair and operator backup verified; A3 natural-trigger acceptance remains open',
             production_clean_verified_at=post['at_hobart'], candidate_code_sha=config['candidate_sha'],
             candidate_meaning='Installed immutable receiver from merged PR646; Pi production is unchanged.',
             receiver_path=config['receiver'], receiver_config_sha256=digest(release / 'user-session-backup.json'),
             implementation_worktree=config['receiver'], implementation_clean=True,
             implementation_branch='detached merged PR646', implementation_base_sha=config['candidate_sha'])
entry['completed_gates'] += ['PR646 applicable exact-head CI and substantive review dispositions',
                           'Ordinary-user task upgrade with authenticated four-pair predecessor history and unchanged principal/triggers/settings',
                           'Explicit operator-triggered September 8 backup PASS/UP_TO_DATE',
                           'Independent archive restore, file metadata/hash and database checks for current observation/control/macro',
                           'Original catalog prefix and all current receipt hashes verified; no active partials']
entry['open_gates'] = ['Natural daily backup on final receiver/runtime after September 9 06:00',
                      'Consolidated A3 acceptance', 'Guarded A4 physical boot and bounded return',
                      'PR607 simplification merge and deployment']
entry['independent_states']['backup'] = {
    'natural_0600_result': 'FAIL: original resolver failure preserved',
    'operator_recovery': {'result': 'PASS', 'status': 'UP_TO_DATE', 'natural_trigger': False,
                          'started_at_utc': load(root / 'operator-recovery-retry-start.json')['at_utc'],
                          'earlier_operator_attempt': {'result': 'FAIL', 'started_at_utc': load(root / 'operator-recovery-start.json')['at_utc'],
                                                       'scheduled_sha256': '85bae5c09a572529c2083b125370ac29b69f00724cc3274f4e48368d15ae2e73',
                                                       'reason': 'Transient SSH banner timeout before macro backup; verified observation/control preserved'},
                          'completed_at_utc': record['timestamps']['completed_at'],
                          'record_path': pointer['record_path'], 'record_sha256': pointer['record_sha256'],
                          'latest_catalog_sequence': entries[-1]['sequence'], 'observation_date': '2026-09-08'}}
entry['catalog_receipts'] = proof['generations']
entry['selected_generation'] = proof['generations'][0]['checks']['observation']['latest_pointer']['generation_id']
entry['a4_readonly_preparation'] = {
    'result': 'READ_ONLY_INSPECTION_COMPLETE', 'a4': 'BLOCKED', 'archive_entry': 'evidence/a4-readonly-metadata.json',
    'device': '/dev/mmcblk0p2', 'serial': '0xfa922545', 'root_uuid': 'ed6c7f1b-238b-41a1-b4b6-7bcdef3270fe',
    'mounted': False, 'media_written': False, 'boot_performed': False,
    'findings': ['SD fstab binds its own 1a36a1cc-01/-02 partitions.',
                 'SD retains enabled historical daily, daily-watchdog and deploy-watchdog timers; clone isolation must inhibit them before boot.',
                 'SD also enables tailscaled, cron and rpi-eeprom-update; inhibit cloned credentials/unknown jobs/firmware updates before the controlled test.',
                 'Current legacy physical-boot validator/policy only accepts plan versions through 1.3; current controlled plan is 1.5. Resolve compatibility without falsifying historical identities.',
                 'Bounded return to the approved NVMe remains unproved.']}
entry['catalog_snapshot'] = {'entries': len(entries), 'sequence': entries[-1]['sequence'],
                            'sha256': digest(target / 'catalog/generations.jsonl'), 'bytes': (target / 'catalog/generations.jsonl').stat().st_size,
                            'prefix_preserved': True, 'archive_entry': 'catalog/generations.jsonl'}
entry['evidence_paths'] = [{'path': archive_path.relative_to(repo).as_posix(), 'bytes': len(payload), 'sha256': archive_sha,
                           'source_files': len(sources), 'manifest_entry': 'manifest.json', 'original_paths_and_hashes': 'manifest.json files[]'},
                          {'path': str(root / 'independent-restore.json'), 'bytes': (root / 'independent-restore.json').stat().st_size,
                           'sha256': digest(root / 'independent-restore.json')}]
entry['verification'] = proof
entry['live_readback'] = post
entry['exact_commands'] = [load(root / 'operator-recovery-start.json')['command'], proof['exact_argv'],
                           'activate_receiver.ps1 -ReceiverCommit cbf920eceedcfd5cc19bd75d86351ddbc7b39e2e']
entry['next_action'] = 'Observe the next natural daily backup after September 9 06:00, authenticate its terminal receipt against unchanged production and receiver, and consolidate A3. Continue bounded A4 preparation; do not write media or reboot before its explicit identity/isolation/return gates pass. Do not replay this completed operator recovery.'
entry['next_action_commands'] = ["Get-ScheduledTaskInfo -TaskName 'AR-local user-session backup'",
                               "Get-Content C:\\code\\backups\\AR-local-pi5-user\\catalog\\latest-scheduled.json",
                               'python verify_local.py --base-url=http://100.78.28.10/ --require-banks-rates']
entry['command_status'] = 'Commands above are read-only next-run observations. Exact completed commands and original artifacts are retained in this packet.'
entry['earliest_start'] = '2026-09-09T06:00:00+10:00'
entry['latest_safe_start'] = '2026-09-09T13:59:59+10:00'
entry['latest_safe_stop'] = '2026-09-09T20:00:00+10:00'
entry['known_risks'] = ['A changed DHCP address may invalidate the fallback hint; strict SSH authentication remains mandatory.',
                        'Operator recovery does not erase the failed natural run or satisfy final-receiver natural proof.',
                        'A4 bounded physical return remains unproved; media writes and reboots remain gated.']
entry['unresolved_findings'] = ['Final-receiver natural daily backup acceptance, A3 consolidation and A4 remain open. PR607 remains draft.']
entry['snapshot_notice'] = 'Operational proof is completed and frozen at the recorded times. Later checks use new output paths; never overwrite this packet or reclassify the failed natural trigger.'
with ledger.open('a', encoding='utf-8', newline='\n') as out:
    out.write('\n\n## Entry `HANDOFF-20260908-LAN-RECOVERY-VERIFIED`\n\n```json\n' + json.dumps(entry, indent=2) + '\n```\n')
summary = repo / 'docs/BACKUP_LAN_RECOVERY_PROOF_20260908.md'
lines = ['# September 8 ordinary-user backup recovery', '',
         'Windows failed to resolve `ar.local` at the natural 06:00 trigger. PR646 installed a bounded, hash-configured LAN fallback while retaining the existing SSH pins. The task update and recovery used the ordinary Windows account with no UAC prompt.', '',
         '- Natural 06:00 run: **FAIL**, preserved.',
         '- First operator attempt at 08:42:12 Hobart: **FAIL** after observation/control verification, due to an SSH banner timeout.',
         '- Operator retry after SSH recovered: **PASS / UP_TO_DATE**; earlier verified components preserved.',
         '- Independent current observation, control and macro archive restoration: **PASS**.',
         f'- Catalog: **{len(entries)} entries**, prior prefix preserved and every receipt hash verified.',
         '- Interactive/Limited principal, daily/logon triggers and settings: unchanged.',
         '- Pi production, legacy task and prior recovery evidence: preserved.', '',
         f"Receiver: `{config['candidate_sha']}`. Production: `{config['protected_sha']}`.",
         f"Configuration SHA256: `{digest(release / 'user-session-backup.json')}`.",
         f"Scheduled receipt SHA256: `{pointer['record_sha256']}`.", '',
         f"[Original evidence packet](evidence/backup-lan-recovery-20260908/{archive_path.name}) contains {len(sources)} source files plus a manifest with exact original paths, byte counts and SHA256 values. Bulk data archives remain at the private paths recorded in the component receipts. Every packet entry was rehashed after ZIP creation; the independent restore script and exact invocation are included.", '',
         'September 8 rates were published by the natural 01:00 ingest and the live dashboard/publication checks passed. The failed laptop backup was separate from publication.', '',
         'Final-receiver natural backup proof remains due after September 9 06:00. A3 consolidation, guarded A4 physical recovery and PR607 simplification remain unfinished. This completed proof is immutable; later verification uses new files.', '']
with summary.open('x', encoding='utf-8') as out:
    out.write('\n'.join(lines))
print(json.dumps({'result': 'PASS', 'archive': str(archive_path), 'archive_sha256': archive_sha,
                  'archive_bytes': len(payload), 'source_files': len(sources), 'catalog_entries': len(entries)}))
