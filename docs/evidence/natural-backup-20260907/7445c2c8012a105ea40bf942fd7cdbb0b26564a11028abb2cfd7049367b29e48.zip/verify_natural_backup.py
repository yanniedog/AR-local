import hashlib,json,sys
from pathlib import Path
from datetime import datetime,timezone
release=Path(r'C:\code\backups\AR-local-user-session\data-runtime-20260906')
output=Path(r'C:\code\backups\AR-local-user-session\natural-proof-20260907')
sys.path.insert(0,str(release/'source'))
import laptop_backup_user_session as user
import laptop_pull_backup as receiver
from laptop_backup_atomic import ReceiverLock
from laptop_backup_transition_contract import partial_paths
config=user.load_config(release/'user-session-backup.json','14e71e6569bc4cab7d4e2c4f7c80ba0272e24a5cd3cba1455c0999bcc6e38318')
user.verify_release(config)
target=Path(config['target'])
def digest(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):value.update(block)
    return value.hexdigest()
with ReceiverLock(target/'user-session-lock'),ReceiverLock(target):
    entries=receiver.catalog_entries(target/'catalog/generations.jsonl')
    assert len(entries)==117,'catalog advanced; reassess before acceptance'
    pointer=json.loads((target/'catalog/latest-scheduled.json').read_bytes())
    scheduled_path=target/pointer['record_path']
    assert digest(scheduled_path)==pointer['record_sha256']
    scheduled=json.loads(scheduled_path.read_bytes())
    assert scheduled['result']=='PASS' and scheduled['detail']['after']['status']=='UP_TO_DATE'
    assert scheduled['candidate_code_sha']==config['candidate_sha'] and scheduled['protected_code_sha']==config['protected_sha']
    assert scheduled['detail']['after']['observation']['observation_date']=='2026-09-07'
    predecessor=scheduled['previous_execution']
    assert digest(target/predecessor['record_path'])==predecessor['record_sha256']
    for entry in entries:
        receipt_path=target/entry['receipt_path']
        assert digest(receipt_path)==entry['receipt_sha256']
    results=[]
    for entry in entries[-3:]:
        path=target/entry['receipt_path']
        receipt=json.loads(path.read_bytes())
        manifest_path=path.parent/'source-manifest.json'
        assert digest(manifest_path)==receipt['source_manifest_sha256']==entry['source_manifest_sha256']
        manifest=json.loads(manifest_path.read_bytes())
        archive=path.parent/(receipt['kind']+'.tar.zst')
        assert archive.stat().st_size==receipt['archive_bytes']
        assert digest(archive)==receipt['archive_sha256']==entry['archive_sha256']
        checks=receiver.restore_verify_archive(target,archive,manifest,receipt['kind'])
        results.append({'sequence':entry['sequence'],'kind':entry['kind'],'receipt_sha256':entry['receipt_sha256'],'archive_sha256':entry['archive_sha256'],'checks':checks})
        print(json.dumps({'sequence':entry['sequence'],'result':'PASS','restored_files':checks['files_verified']}),flush=True)
    assert not partial_paths(target),'partial backup files remain'
    report={'at':datetime.now(timezone.utc).isoformat(),'result':'PASS','candidate_sha':config['candidate_sha'],'protected_sha':config['protected_sha'],'scheduled_path':str(scheduled_path),'scheduled_sha256':pointer['record_sha256'],'catalog_entries_verified':len(entries),'generations':results,'partials':[],'uac_used':False,'proof_scope':'Independent current archive restoration and hash verification; scheduler start evidence is recorded separately.'}
    report_path=output/'independent-restore.json'
    with report_path.open('x',encoding='utf-8') as stream:json.dump(report,stream,sort_keys=True)
print(json.dumps({'result':'PASS','report':str(report_path),'report_sha256':digest(report_path)}),flush=True)
